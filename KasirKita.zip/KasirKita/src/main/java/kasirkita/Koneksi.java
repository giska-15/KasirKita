
package kasirkita;

import com.mysql.cj.jdbc.MysqlDataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class Koneksi {
    
    public static Connection Go() {
        try {
            MysqlDataSource C = new MysqlDataSource();
            C.setServerName("localhost");
            C.setDatabaseName("klm4");
            C.setUser("root");
            C.setPassword("");
            C.setPortNumber(3306);
            C.setServerTimezone("Asia/Jakarta");
            Connection con = C.getConnection();
            return con;
        } catch (SQLException e) {
            System.err.println("Error: "+e.getMessage());
        }
        return null;
    }

//    public static void main(String[] args) {
//        if (Go() == null) {
//            System.out.println("Failed");
//        } else {
//            System.out.println("Success");
//        }
//    }
}
