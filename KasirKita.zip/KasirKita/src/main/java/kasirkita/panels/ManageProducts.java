package kasirkita.panels;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import kasirkita.Koneksi;

public class ManageProducts extends javax.swing.JPanel {

    public ManageProducts() {
        initComponents();
        RefreshData();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnTambah = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnHapus = new javax.swing.JButton();
        btnRefresh = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        btnCari = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setPreferredSize(new java.awt.Dimension(700, 500));
        setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));

        btnTambah.setText("Tambah");
        btnTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit");
        btnEdit.setEnabled(false);
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnHapus.setText("Hapus");
        btnHapus.setEnabled(false);
        btnHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusActionPerformed(evt);
            }
        });

        btnRefresh.setText("Refresh");
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });

        btnCari.setText("Cari");
        btnCari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCariActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnTambah)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnEdit)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnHapus)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnRefresh)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 149, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCari, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
                    .addComponent(jTextField1))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnTambah, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                    .addComponent(btnEdit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnHapus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnRefresh, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextField1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnCari)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        add(jPanel1, java.awt.BorderLayout.PAGE_START);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nama", "Kategori", "Harga", "Stok", "Barcode"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        add(jScrollPane1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void btnTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahActionPerformed
        String nama = JOptionPane.showInputDialog(this, "Nama Produk");
        if (nama == null || nama.isBlank()) return;
        String hargaStr = JOptionPane.showInputDialog(this, "Harga");
        if (hargaStr == null || hargaStr.isBlank()) return;
        String stokStr = JOptionPane.showInputDialog(this, "Stok");
        if (stokStr == null || stokStr.isBlank()) return;
        String barcode = JOptionPane.showInputDialog(this, "Barcode (optional)");
        String idKatStr = JOptionPane.showInputDialog(this, "ID Kategori (optional)");
        try {
            double harga = Double.parseDouble(hargaStr);
            if (harga < 0) {
                JOptionPane.showMessageDialog(this, "Harga tidak boleh negatif", "Validasi", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int stok = Integer.parseInt(stokStr);
            if (stok < 0) {
                JOptionPane.showMessageDialog(this, "Stok tidak boleh negatif", "Validasi", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            Connection C = Koneksi.Go();
            if (C == null) {
                JOptionPane.showMessageDialog(this, "Gagal terhubung ke database", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String Query = "INSERT INTO produk(nama_produk,harga,stok,barcode,id_kategori) VALUES(?,?,?,?,?)";
            try (PreparedStatement PS = C.prepareStatement(Query)) {
                PS.setString(1, nama.trim());
                PS.setDouble(2, harga);
                PS.setInt(3, stok);
                if (barcode == null || barcode.isBlank()) {
                    PS.setNull(4, java.sql.Types.VARCHAR);
                } else {
                    PS.setString(4, barcode.trim());
                }
                if (idKatStr == null || idKatStr.isBlank()) {
                    PS.setNull(5, java.sql.Types.INTEGER);
                } else {
                    int idKat = Integer.parseInt(idKatStr);
                    PS.setInt(5, idKat);
                }
                PS.executeUpdate();
                JOptionPane.showMessageDialog(this, "Produk berhasil ditambahkan");
            } finally {
                if (C != null) {
                    try {
                        C.close();
                    } catch (Exception ex) {
                        // Log but don't throw
                    }
                }
            }
            RefreshData();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Format angka tidak valid: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error saat menambah produk: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnTambahActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        btnEdit.setEnabled(false);
        btnHapus.setEnabled(false);
        jTable1.clearSelection();
        RefreshData();
    }//GEN-LAST:event_btnRefreshActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        int data = jTable1.getSelectedRow();
        if (data != -1) {
            btnEdit.setEnabled(true);
            btnHapus.setEnabled(true);
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
        int row = jTable1.getSelectedRow();
        if (row == -1) return;
        Object idObj = jTable1.getValueAt(row, 0);
        int id = Integer.parseInt(idObj.toString());
        String namaOld = String.valueOf(jTable1.getValueAt(row, 1));
        String kategoriOld = String.valueOf(jTable1.getValueAt(row, 2));
        String hargaOld = String.valueOf(jTable1.getValueAt(row, 3));
        String stokOld = String.valueOf(jTable1.getValueAt(row, 4));
        String barcodeOld = String.valueOf(jTable1.getValueAt(row, 5));

        String nama = JOptionPane.showInputDialog(this, "Nama Produk", namaOld);
        if (nama == null || nama.isBlank()) return;
        String hargaStr = JOptionPane.showInputDialog(this, "Harga", hargaOld);
        if (hargaStr == null || hargaStr.isBlank()) return;
        String stokStr = JOptionPane.showInputDialog(this, "Stok", stokOld);
        if (stokStr == null || stokStr.isBlank()) return;
        String barcode = JOptionPane.showInputDialog(this, "Barcode (optional)", barcodeOld);
        String idKatStr = JOptionPane.showInputDialog(this, "ID Kategori (optional)", kategoriOld);
        try {
            double harga = Double.parseDouble(hargaStr);
            if (harga < 0) {
                JOptionPane.showMessageDialog(this, "Harga tidak boleh negatif", "Validasi", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int stok = Integer.parseInt(stokStr);
            if (stok < 0) {
                JOptionPane.showMessageDialog(this, "Stok tidak boleh negatif", "Validasi", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            Connection C = Koneksi.Go();
            if (C == null) {
                JOptionPane.showMessageDialog(this, "Gagal terhubung ke database", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String Query = "UPDATE produk SET nama_produk=?, harga=?, stok=?, barcode=?, id_kategori=? WHERE id_produk=?";
            try (PreparedStatement PS = C.prepareStatement(Query)) {
                PS.setString(1, nama.trim());
                PS.setDouble(2, harga);
                PS.setInt(3, stok);
                if (barcode == null || barcode.isBlank()) {
                    PS.setNull(4, java.sql.Types.VARCHAR);
                } else {
                    PS.setString(4, barcode.trim());
                }
                if (idKatStr == null || idKatStr.isBlank()) {
                    PS.setNull(5, java.sql.Types.INTEGER);
                } else {
                    PS.setInt(5, Integer.parseInt(idKatStr));
                }
                PS.setInt(6, id);
                PS.executeUpdate();
                JOptionPane.showMessageDialog(this, "Produk berhasil diupdate");
            } finally {
                if (C != null) {
                    try {
                        C.close();
                    } catch (Exception ex) {
                        // Log but don't throw
                    }
                }
            }
            RefreshData();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Format angka tidak valid: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error saat mengupdate produk: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusActionPerformed
        int row = jTable1.getSelectedRow();
        if (row == -1) return;
        Object idObj = jTable1.getValueAt(row, 0);
        int id = Integer.parseInt(idObj.toString());
        int conf = JOptionPane.showConfirmDialog(this, "Hapus produk ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if (conf != JOptionPane.YES_OPTION) return;
        try {
            Connection C = Koneksi.Go();
            if (C == null) {
                JOptionPane.showMessageDialog(this, "Gagal terhubung ke database", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String Query = "DELETE FROM produk WHERE id_produk=?";
            try (PreparedStatement PS = C.prepareStatement(Query)) {
                PS.setInt(1, id);
                PS.executeUpdate();
                JOptionPane.showMessageDialog(this, "Produk berhasil dihapus");
            } finally {
                if (C != null) {
                    try {
                        C.close();
                    } catch (Exception ex) {
                        // Log but don't throw
                    }
                }
            }
            RefreshData();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error saat menghapus produk: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnHapusActionPerformed

    private void btnCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCariActionPerformed
        // TODO add your handling code here:
        String keyword = jTextField1.getText();
        if (keyword == null || keyword.isBlank()) {
            RefreshData();
            return;
        }
        SearchData(keyword.trim());
    }//GEN-LAST:event_btnCariActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCari;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnTambah;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private static javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables

    public static void RefreshData() {
        try {
            jTable1.setRowHeight(30);
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            for (int i = model.getRowCount()-1; i >= 0; i--) {
                model.removeRow(i);
            }
            
            Connection C = Koneksi.Go();
            if (C == null) {
                javax.swing.JOptionPane.showMessageDialog(null, "Gagal terhubung ke database", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String Query = "SELECT id_produk, COALESCE(CAST(id_kategori AS CHAR),'') AS id_kategori, nama_produk, harga, stok, COALESCE(barcode,'') AS barcode FROM produk";
            try (Statement S = C.createStatement(); ResultSet R = S.executeQuery(Query)) {
                while (R.next()) {
                    Object [] data = {
                        R.getInt("id_produk"),
                        R.getString("nama_produk"),
                        R.getString("id_kategori"),
                        R.getDouble("harga"),
                        R.getInt("stok"),
                        R.getString("barcode")
                    };
                    model.addRow(data);
                }
            } finally {
                if (C != null) {
                    try {
                        C.close();
                    } catch (Exception e) {
                        // Log but don't throw
                    }
                }
            }
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, "Error saat memuat data: " + e.getMessage(), "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void SearchData(String keyword) {
        try {
            jTable1.setRowHeight(30);
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            for (int i = model.getRowCount()-1; i >= 0; i--) {
                model.removeRow(i);
            }
            
            Connection C = Koneksi.Go();
            if (C == null) {
                javax.swing.JOptionPane.showMessageDialog(null, "Gagal terhubung ke database", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String sql = "SELECT id_produk, COALESCE(CAST(id_kategori AS CHAR),'') AS id_kategori, nama_produk, harga, stok, COALESCE(barcode,'') AS barcode FROM produk WHERE nama_produk LIKE ?";
            try (PreparedStatement PS = C.prepareStatement(sql)) {
                String like = "%" + keyword + "%";
                PS.setString(1, like);
                int count = 0;
                try (ResultSet R = PS.executeQuery()) {
                    while (R.next()) {
                        Object [] data = {
                            R.getInt("id_produk"),
                            R.getString("nama_produk"),
                            R.getString("id_kategori"),
                            R.getDouble("harga"),
                            R.getInt("stok"),
                            R.getString("barcode")
                        };
                        model.addRow(data);
                        count++;
                    }
                }
                if (count == 0) {
                    javax.swing.JOptionPane.showMessageDialog(null, "Data tidak ditemukan untuk nama: " + keyword, "Info", javax.swing.JOptionPane.INFORMATION_MESSAGE);
                }
            } finally {
                if (C != null) {
                    try {
                        C.close();
                    } catch (Exception e) {
                        // Log but don't throw
                    }
                }
            }
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, "Error saat mencari data: " + e.getMessage(), "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }
}
